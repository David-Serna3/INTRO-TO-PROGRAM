/*
Author: David Serna
Date: 9/19/2018

compute expression
*/

class Ex_1_5 {
	public static void main(String[] args) {
		System.out.println( ( (9.5 * 4.5) - (2.5 * 3) ) / (45.5 - 3.5) );
	}
}