/* 
Author: David Serna
Date: October 9, 2017
*/

import java.util.Scanner;
public class MyFirstClass {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double celsius = 0.0;
		double fahrenheit = 0.0;
		System.out.println("Enter degrees in Celsius");
		celsius = input.nextDouble();
		
		fahrenheit = (9.0 / 5.0) * celsius + 32.0;
		
		System.out.println("Fahreneit:" + fahrenheit);

	}

}
