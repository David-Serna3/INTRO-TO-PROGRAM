/*

 Author: David Serna
 Date: October 10, 2018
 */




import java.util.Scanner;
public class chapter213 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		final double intRate = 0.00417;
		double saving = 0.0;
		double oneMonth = 0.0;
		double twoMonth = 0.0;
		double treMonth = 0.0;
		double furMonth = 0.0;
		double fivMonth = 0.0;
		double sixMonth = 0.0;
		
		System.out.println("Enter the annual savings amount:");
		saving = input.nextDouble();
		oneMonth = saving * (1 + intRate);
		twoMonth = (saving + oneMonth) * (1 + intRate);
		treMonth = (saving + twoMonth) * (1 + intRate);
		furMonth = (saving + treMonth) * (1 + intRate);
		fivMonth = (saving + furMonth) * (1 + intRate);
		sixMonth = (saving + fivMonth) * (1 + intRate);
		
		System.out.println("This is the account value after six months: " + sixMonth);

	}

}
